# Architecture

## High-level flow

```text
Browser
  |
  v
Cloudflare / WAF
  |
  v
Next.js Web
  |
  v
API (NestJS)
  |
  +--> PostgreSQL
  +--> Redis
  +--> Object Storage
  +--> KYC Provider
  +--> Payment Provider
  +--> Email/SMS Provider
```

## Investor flow

```text
Landing page
 -> Register
 -> Email verification
 -> KYC/KYB
 -> Approved account
 -> View projects
 -> Review disclosures/documents
 -> Investment order
 -> Payment
 -> Ledger transaction
 -> Investment record
 -> Distributions
 -> Withdrawal
```

## Admin flow

```text
Admin login + 2FA
 -> Dashboard
 -> KYC review
 -> Project management
 -> Deposit review
 -> Withdrawal review
 -> Distribution processing
 -> Reports
 -> Audit logs
```

## Financial design

The application should not maintain an editable `users.balance` as the source of truth.

Use a double-entry ledger:

```text
Transaction
  -> Ledger Entry: Debit account A
  -> Ledger Entry: Credit account B
```

Balances are derived from posted ledger entries and reconciled against the payment/banking provider.

## Security principles

- Passwords hashed with Argon2id.
- Encrypt sensitive data at rest where appropriate.
- TLS everywhere.
- MFA for admins and preferably investors.
- RBAC for administrative actions.
- Immutable audit trail for financial/admin actions.
- Idempotency keys for payment and financial endpoints.
- Server-side authorization on every protected resource.
- Rate limiting and abuse protection.
- Malware scanning for uploaded documents.
- Secrets stored outside source control.
