# Compliance checklist

This is a planning checklist, not legal advice.

Before launch, obtain qualified legal/compliance advice for:

- [ ] Securities / investment-offer classification
- [ ] Crowdfunding rules, if applicable
- [ ] Investor eligibility and geographic restrictions
- [ ] KYC/KYB
- [ ] AML/CFT
- [ ] Sanctions screening
- [ ] Beneficial-owner checks for companies
- [ ] Payment processing
- [ ] Money transmission / custody questions
- [ ] Client-money segregation, if applicable
- [ ] Tax reporting
- [ ] Privacy/data protection
- [ ] Marketing/financial-promotion rules
- [ ] Risk disclosures
- [ ] Investment contracts
- [ ] Refund/cancellation rules
- [ ] Record retention
- [ ] Complaint handling

Do not market returns as guaranteed unless the legal and contractual basis genuinely supports that statement.
