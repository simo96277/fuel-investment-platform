# API blueprint

## Public

```text
GET  /api/projects
GET  /api/projects/:id
```

## Authentication

```text
POST /api/auth/register
POST /api/auth/login
POST /api/auth/logout
POST /api/auth/verify-email
POST /api/auth/forgot-password
POST /api/auth/reset-password
POST /api/auth/2fa/enable
POST /api/auth/2fa/verify
```

## Investor

```text
GET  /api/me
PUT  /api/me/profile

POST /api/kyc
GET  /api/kyc/status

GET  /api/wallet
GET  /api/transactions

POST /api/deposits
GET  /api/deposits

POST /api/investments
GET  /api/investments
GET  /api/investments/:id

POST /api/withdrawals
GET  /api/withdrawals

GET  /api/distributions
GET  /api/contracts
POST /api/contracts/:id/sign
```

## Admin

```text
GET  /api/admin/dashboard
GET  /api/admin/users
GET  /api/admin/kyc
POST /api/admin/kyc/:id/approve
POST /api/admin/kyc/:id/reject

POST /api/admin/projects
PUT  /api/admin/projects/:id
GET  /api/admin/projects

GET  /api/admin/deposits
GET  /api/admin/withdrawals
POST /api/admin/withdrawals/:id/approve
POST /api/admin/withdrawals/:id/reject

GET  /api/admin/audit-logs
GET  /api/admin/reports
```

For all money-moving endpoints:
- require authentication
- authorize the resource owner/admin role
- validate amounts server-side
- use idempotency keys
- write an audit record
- post ledger entries only after the relevant business/payment state is confirmed
