# Database design

## Core entities

```text
users
user_profiles
user_security
kyc_verifications
kyc_documents

projects
project_documents
investment_offers
investments

accounts
ledger_transactions
ledger_entries

deposits
withdrawals
distributions

payment_methods
payment_transactions

contracts
contract_signatures

notifications
support_tickets

admin_users
admin_roles
admin_user_roles
audit_logs
```

## Key relationships

```text
users 1---1 user_profiles
users 1---1 user_security
users 1---N kyc_verifications
users 1---N investments
users 1---N deposits
users 1---N withdrawals

projects 1---N project_documents
projects 1---N investments

ledger_transactions 1---N ledger_entries
accounts 1---N ledger_entries

investments 1---N distributions
investments 1---N contracts
contracts 1---N contract_signatures
```

## Important rule

Financial state must be represented by immutable/postable ledger entries. Corrections should be made through reversing/adjusting transactions, not by silently editing historical transactions.
