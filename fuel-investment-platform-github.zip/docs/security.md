# Security checklist

## Authentication
- [ ] Argon2id password hashing
- [ ] Email verification
- [ ] MFA/2FA
- [ ] Secure session rotation
- [ ] Login throttling
- [ ] Password reset tokens are short-lived and single-use

## Authorization
- [ ] RBAC
- [ ] Object-level authorization
- [ ] Separate financial approval permissions
- [ ] Dual approval for configurable high-value withdrawals

## Payments
- [ ] Idempotency
- [ ] Webhook signature verification
- [ ] Replay protection
- [ ] Reconciliation jobs
- [ ] No raw card data stored unless explicitly supported by a compliant payment architecture

## Files
- [ ] Virus/malware scanning
- [ ] Content-type validation
- [ ] Size limits
- [ ] Private object storage
- [ ] Signed download URLs

## Operations
- [ ] Centralized logs
- [ ] Audit logs
- [ ] Monitoring and alerts
- [ ] Database backups
- [ ] Disaster recovery plan
- [ ] Dependency scanning
- [ ] Penetration test before production
