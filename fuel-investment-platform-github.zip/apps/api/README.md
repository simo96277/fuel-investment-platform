# API app

Recommended NestJS modules:

```text
auth
users
kyc
projects
investments
wallet
ledger
deposits
withdrawals
distributions
contracts
notifications
support
admin
audit
```

Keep payment-provider webhooks isolated, verify signatures, and make all financial handlers idempotent.
