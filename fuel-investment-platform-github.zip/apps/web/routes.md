# Frontend route map

| Route | Purpose | Auth |
|---|---|---|
| `/` | Landing page | Public |
| `/projects` | Project list | Public |
| `/projects/[id]` | Project details/disclosures | Public |
| `/register` | Account creation | Public |
| `/login` | Login | Public |
| `/dashboard` | Investor dashboard | Investor |
| `/dashboard/wallet` | Wallet/account view | Investor |
| `/dashboard/investments` | Investments | Investor |
| `/dashboard/deposits` | Deposits | Investor |
| `/dashboard/withdrawals` | Withdrawals | Investor |
| `/dashboard/transactions` | Ledger-facing history | Investor |
| `/dashboard/contracts` | Contracts | Investor |
| `/dashboard/profile` | Profile/KYC | Investor |
| `/admin` | Admin dashboard | Admin |
| `/admin/users` | User management | Admin |
| `/admin/kyc` | KYC review | Admin |
| `/admin/projects` | Project management | Admin |
| `/admin/deposits` | Deposit operations | Admin |
| `/admin/withdrawals` | Withdrawal operations | Admin |
| `/admin/distributions` | Distribution operations | Admin |
| `/admin/reports` | Reporting | Admin |
| `/admin/audit-logs` | Audit trail | Admin |
