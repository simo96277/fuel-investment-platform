# Web app

Recommended routes:

```text
/
 /projects
 /projects/[id]
 /login
 /register
 /verify-email
 /kyc
 /dashboard
 /dashboard/wallet
 /dashboard/investments
 /dashboard/deposits
 /dashboard/withdrawals
 /dashboard/transactions
 /dashboard/contracts
 /dashboard/profile
 /dashboard/security

 /admin
 /admin/users
 /admin/kyc
 /admin/projects
 /admin/deposits
 /admin/withdrawals
 /admin/distributions
 /admin/reports
 /admin/audit-logs
```

Build this as a separate Next.js application and connect it to the API.
