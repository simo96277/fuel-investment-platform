# Fuel Investment Platform

A production-oriented blueprint/starter repository for an investment platform centered on fuel-station projects.

> **Important:** This repository is a technical starter, not legal or financial advice. Before accepting investor funds, validate the securities/crowdfunding, KYC/AML, payments, money-transmission/custody, tax, consumer-protection, and privacy requirements applicable to the countries where the company and investors are located.

## Architecture

- Frontend: Next.js + TypeScript
- Backend: NestJS + TypeScript
- Database: PostgreSQL
- Cache/queues: Redis
- Object storage: S3-compatible storage
- Authentication: secure session/JWT approach + 2FA
- Payments: integrate a regulated payment provider appropriate to the legal structure
- KYC: integrate a compliant identity-verification provider
- Financial accounting: double-entry ledger; never mutate balances directly

## Main modules

- Public website
- Authentication and email verification
- Investor profile
- KYC/KYB
- Projects and project documents
- Investment offers
- Wallet/account views
- Deposits and withdrawals
- Double-entry ledger
- Distributions
- Contracts and signatures
- Notifications
- Support
- Admin dashboard
- Audit logs
- Reports

## Repository layout

```text
apps/
  web/       # investor/public frontend
  api/       # backend API
packages/
  db/        # database schema and migrations
  shared/    # shared types/constants
docs/
  architecture.md
  database.md
  api.md
  security.md
  compliance-checklist.md
infra/
  docker-compose.yml
```

## Suggested first steps

1. Confirm the legal model and investor eligibility rules.
2. Choose regulated payment/KYC providers.
3. Implement authentication and KYC.
4. Implement projects and investment records.
5. Implement the ledger and reconciliation.
6. Add deposits/withdrawals through the approved payment architecture.
7. Add contracts and audit logging.
8. Perform security, accounting, and compliance testing before launch.

## Local development

Prerequisites:
- Node.js 20+
- PostgreSQL 16+
- Redis 7+
- Docker (recommended)

Copy environment templates from each app and never commit real secrets.

